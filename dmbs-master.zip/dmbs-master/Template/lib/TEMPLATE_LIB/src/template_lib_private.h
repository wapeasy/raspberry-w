/*
             DMBS Build System
      Released into the public domain.

   dean [at] fourwalledcubicle [dot] com
         www.fourwalledcubicle.com
 */

// Include Guard
#pragma once

#include <stdint.h>
#include <stddef.h>
#include <avr/io.h>
