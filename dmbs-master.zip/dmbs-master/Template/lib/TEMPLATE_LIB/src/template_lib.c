/*
             DMBS Build System
      Released into the public domain.

   dean [at] fourwalledcubicle [dot] com
         www.fourwalledcubicle.com
 */

#include "template_lib.h"
#include "template_lib_private.h"
