/*
             DMBS Build System
      Released into the public domain.

   dean [at] fourwalledcubicle [dot] com
         www.fourwalledcubicle.com
 */

// Include Guard
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Software version
#define TEMPLATE_LIB_VERSION 100

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
}
#endif
